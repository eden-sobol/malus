new App([
    e("p", [
        "hello",
        "<br><br>hi"
    ], {})
], {

})
